// frontend/src/components/Emergency/EmergencyIntervention.jsx
import React, { useState, useEffect } from 'react';
import APIService from '../../services/api';
import WebSocketService from '../../services/websocket';
import './EmergencyIntervention.css';

const EmergencyIntervention = ({ crisisLevel, emotionData, userId }) => {
    const [isConnecting, setIsConnecting] = useState(false);
    const [counselorConnected, setCounselorConnected] = useState(false);
    const [safetyCheckActive, setSafetyCheckActive] = useState(false);
    const [countdown, setCountdown] = useState(10);

    useEffect(() => {
        if (crisisLevel === 'HIGH' || crisisLevel === 'SEVERE') {
            startEmergencyProtocol();
        }
    }, [crisisLevel]);

    const startEmergencyProtocol = async () => {
        // Trigger emergency backend protocol
        await APIService.triggerEmergency(userId, crisisLevel, emotionData);
        
        // Start safety check countdown
        startSafetyCheck();
    };

    const startSafetyCheck = () => {
        setSafetyCheckActive(true);
        const countdownInterval = setInterval(() => {
            setCountdown(prev => {
                if (prev <= 1) {
                    clearInterval(countdownInterval);
                    escalateEmergency();
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };

    const escalateEmergency = async () => {
        // Notify emergency contacts and authorities
        await APIService.panicButton(userId);
    };

    const connectWithCounselor = async () => {
        setIsConnecting(true);
        try {
            const response = await APIService.connectCounselor(userId);
            if (response.success) {
                setCounselorConnected(true);
                setSafetyCheckActive(false);
            }
        } catch (error) {
            console.error('Counselor connection failed:', error);
        } finally {
            setIsConnecting(false);
        }
    };

    const confirmSafety = () => {
        setSafetyCheckActive(false);
        setCountdown(10);
        // Send safety confirmation to backend
        WebSocketService.socket.emit('safety_confirmed', { userId });
    };

    return (
        <div className={`emergency-intervention ${crisisLevel.toLowerCase()}`}>
            <div className="emergency-header">
                <h3>🚨 Support Session Activated</h3>
                <div className="crisis-level">Crisis Level: {crisisLevel}</div>
            </div>

            <div className="emergency-actions">
                {!counselorConnected && (
                    <button 
                        className="counselor-btn"
                        onClick={connectWithCounselor}
                        disabled={isConnecting}
                    >
                        {isConnecting ? 'Connecting...' : 'Connect with Counselor Now'}
                    </button>
                )}

                {counselorConnected && (
                    <div className="connection-status">
                        ✅ Connected with professional counselor
                    </div>
                )}

                {safetyCheckActive && (
                    <div className="safety-check">
                        <p>Are you safe? We'll notify your emergency contacts in:</p>
                        <div className="countdown">{countdown}s</div>
                        <button className="safety-btn" onClick={confirmSafety}>
                            I'm Safe
                        </button>
                    </div>
                )}
            </div>

            <div className="emergency-resources">
                <h4>Immediate Help Resources:</h4>
                <ul>
                    <li>National Suicide Prevention Lifeline: 1-800-273-8255</li>
                    <li>Crisis Text Line: Text HOME to 741741</li>
                    <li>Emergency Services: 911</li>
                </ul>
            </div>

            <div className="breathing-guide">
                <h4>Quick Grounding Exercise:</h4>
                <p>Name 5 things you can see, 4 things you can touch, 3 things you can hear, 
                   2 things you can smell, 1 thing you can taste.</p>
            </div>
        </div>
    );
};

export default EmergencyIntervention;
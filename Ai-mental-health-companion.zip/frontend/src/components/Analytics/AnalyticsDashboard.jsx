import React from 'react';
import './AnalyticsDashboard.css';

const AnalyticsDashboard = ({ user }) => {
    // Mock data for demonstration
    const moodData = [
        { day: 'Mon', mood: 7 },
        { day: 'Tue', mood: 5 },
        { day: 'Wed', mood: 8 },
        { day: 'Thu', mood: 6 },
        { day: 'Fri', mood: 4 },
        { day: 'Sat', mood: 9 },
        { day: 'Sun', mood: 7 }
    ];

    const emotionDistribution = [
        { emotion: 'Happy', percentage: 40 },
        { emotion: 'Calm', percentage: 25 },
        { emotion: 'Anxious', percentage: 15 },
        { emotion: 'Sad', percentage: 12 },
        { emotion: 'Angry', percentage: 8 }
    ];

    return (
        <div className="analytics-dashboard">
            <div className="analytics-header">
                <h2>Your Mental Health Analytics</h2>
                <p>Track your emotional journey and progress</p>
            </div>

            <div className="stats-grid">
                <div className="stat-card">
                    <h3>Current Mood</h3>
                    <div className="stat-value">7/10</div>
                    <p>Good</p>
                </div>
                
                <div className="stat-card">
                    <h3>Sessions This Week</h3>
                    <div className="stat-value">12</div>
                    <p>+3 from last week</p>
                </div>
                
                <div className="stat-card">
                    <h3>Wellness Score</h3>
                    <div className="stat-value">78%</div>
                    <p>Improving</p>
                </div>
                
                <div className="stat-card">
                    <h3>Stress Level</h3>
                    <div className="stat-value">Medium</div>
                    <p>Manageable</p>
                </div>
            </div>

            <div className="charts-section">
                <div className="chart-card">
                    <h3>Weekly Mood Trend</h3>
                    <div className="mood-chart">
                        {moodData.map((data, index) => (
                            <div key={index} className="chart-bar-container">
                                <div 
                                    className="chart-bar" 
                                    style={{ height: `${data.mood * 10}%` }}
                                ></div>
                                <span className="chart-label">{data.day}</span>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="chart-card">
                    <h3>Emotion Distribution</h3>
                    <div className="emotion-chart">
                        {emotionDistribution.map((item, index) => (
                            <div key={index} className="emotion-item">
                                <span className="emotion-name">{item.emotion}</span>
                                <div className="emotion-bar-container">
                                    <div 
                                        className="emotion-bar" 
                                        style={{ width: `${item.percentage}%` }}
                                    ></div>
                                </div>
                                <span className="emotion-percentage">{item.percentage}%</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="insights-section">
                <h3>Personalized Insights</h3>
                <div className="insights">
                    <div className="insight positive">
                        <strong>Positive Trend:</strong> Your mood has improved 15% this week compared to last week.
                    </div>
                    <div className="insight suggestion">
                        <strong>Suggestion:</strong> Try morning meditation to maintain your positive momentum.
                    </div>
                    <div className="insight reminder">
                        <strong>Reminder:</strong> You're doing great! Remember to take breaks and practice self-care.
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AnalyticsDashboard;
import React, { useState } from 'react';
import APIService from '../../services/api';
import './WellnessCenter.css';

const WellnessCenter = ({ user }) => {
    const [activeExercise, setActiveExercise] = useState(null);
    const [breathingActive, setBreathingActive] = useState(false);
    const [breathingPhase, setBreathingPhase] = useState('ready');
    const [breathingTime, setBreathingTime] = useState(0);

    const startBreathingExercise = async () => {
        try {
            const response = await APIService.getBreathingExercise();
            if (response.success) {
                setActiveExercise(response.exercise);
                setBreathingActive(true);
                startBreathingCycle(response.exercise);
            }
        } catch (error) {
            console.error('Error starting exercise:', error);
            // Fallback exercise
            const fallbackExercise = {
                name: '4-7-8 Breathing',
                description: 'Calming technique for stress and anxiety relief',
                instructions: [
                    'Sit comfortably with your back straight',
                    'Exhale completely through your mouth',
                    'Close your mouth and inhale quietly through your nose for 4 seconds',
                    'Hold your breath for 7 seconds',
                    'Exhale completely through your mouth for 8 seconds',
                    'Repeat this cycle 4-5 times'
                ],
                duration: 5
            };
            setActiveExercise(fallbackExercise);
            setBreathingActive(true);
            startBreathingCycle(fallbackExercise);
        }
    };

    const startBreathingCycle = (exercise) => {
        const phases = ['inhale', 'hold', 'exhale', 'hold'];
        const times = [4, 7, 8, 4]; // 4-7-8 breathing pattern
        let phaseIndex = 0;
        
        const updateBreathing = () => {
            setBreathingPhase(phases[phaseIndex]);
            setBreathingTime(times[phaseIndex]);
            
            const timer = setInterval(() => {
                setBreathingTime(prev => {
                    if (prev <= 1) {
                        clearInterval(timer);
                        phaseIndex = (phaseIndex + 1) % phases.length;
                        updateBreathing();
                        return times[phaseIndex];
                    }
                    return prev - 1;
                });
            }, 1000);
        };
        
        updateBreathing();
    };

    const stopBreathingExercise = () => {
        setBreathingActive(false);
        setActiveExercise(null);
        setBreathingPhase('ready');
        setBreathingTime(0);
    };

    const wellnessActivities = [
        {
            id: 1,
            name: 'Breathing Exercises',
            description: 'Calm your mind with guided breathing techniques',
            icon: '🌬️',
            color: '#667eea',
            action: startBreathingExercise
        },
        {
            id: 2,
            name: 'Guided Meditation',
            description: 'Find peace through mindfulness meditation',
            icon: '🧘',
            color: '#4ecdc4',
            action: () => alert('Meditation sessions coming soon! Try the breathing exercise for now.')
        },
        {
            id: 3,
            name: 'Journal Prompts',
            description: 'Express your thoughts and feelings',
            icon: '📔',
            color: '#45b7d1',
            action: () => {
                const prompts = [
                    "What am I grateful for today?",
                    "What's worrying me right now?",
                    "What would make today better?",
                    "How am I really feeling?"
                ];
                const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
                alert(`Journal Prompt: ${randomPrompt}`);
            }
        },
        {
            id: 4,
            name: 'Relaxing Sounds',
            description: 'Calm your mind with ambient sounds',
            icon: '🎵',
            color: '#96ceb4',
            action: () => alert('Sound therapy coming soon!')
        },
        {
            id: 5,
            name: 'Quick Stretches',
            description: 'Release tension with simple stretches',
            icon: '💪',
            color: '#feca57',
            action: () => alert('Stretch exercises coming soon!')
        },
        {
            id: 6,
            name: 'Mindful Moments',
            description: 'Short mindfulness exercises',
            icon: '🌿',
            color: '#ff9ff3',
            action: () => alert('Mindfulness exercises coming soon!')
        }
    ];

    const getBreathingInstructions = () => {
        switch (breathingPhase) {
            case 'inhale':
                return 'Breathe in slowly through your nose...';
            case 'hold':
                return 'Hold your breath...';
            case 'exhale':
                return 'Breathe out slowly through your mouth...';
            default:
                return 'Get ready to begin breathing...';
        }
    };

    return (
        <div className="wellness-center">
            <div className="wellness-header">
                <h2>🌱 Wellness Center</h2>
                <p>Tools and exercises for your mental wellbeing</p>
            </div>

            {breathingActive && activeExercise ? (
                <div className="active-breathing-exercise">
                    <div className="breathing-container">
                        <h3>{activeExercise.name}</h3>
                        <p>{activeExercise.description}</p>
                        
                        <div className="breathing-visualization">
                            <div className={`breathing-circle ${breathingPhase}`}>
                                <div className="breathing-text">
                                    <div className="phase">{breathingPhase.toUpperCase()}</div>
                                    <div className="timer">{breathingTime}s</div>
                                </div>
                            </div>
                            <div className="breathing-instruction">
                                {getBreathingInstructions()}
                            </div>
                        </div>

                        <div className="exercise-instructions">
                            <h4>Full Instructions:</h4>
                            <ol>
                                {activeExercise.instructions.map((instruction, index) => (
                                    <li key={index}>{instruction}</li>
                                ))}
                            </ol>
                        </div>

                        <button 
                            className="stop-exercise-btn"
                            onClick={stopBreathingExercise}
                        >
                            Stop Exercise
                        </button>
                    </div>
                </div>
            ) : (
                <>
                    <div className="wellness-stats">
                        <div className="stat-card">
                            <div className="stat-icon">😊</div>
                            <div className="stat-info">
                                <h3>Mood Boost</h3>
                                <p>Practice daily for better mood</p>
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-icon">💤</div>
                            <div className="stat-info">
                                <h3>Better Sleep</h3>
                                <p>Relax before bedtime</p>
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-icon">🎯</div>
                            <div className="stat-info">
                                <h3>Focus</h3>
                                <p>Improve concentration</p>
                            </div>
                        </div>
                    </div>

                    <div className="wellness-grid">
                        {wellnessActivities.map(activity => (
                            <div 
                                key={activity.id} 
                                className="wellness-card"
                                style={{ '--card-color': activity.color }}
                            >
                                <div className="card-header">
                                    <div className="card-icon" style={{ backgroundColor: activity.color }}>
                                        {activity.icon}
                                    </div>
                                    <h3>{activity.name}</h3>
                                </div>
                                <p>{activity.description}</p>
                                <button 
                                    onClick={activity.action}
                                    style={{ backgroundColor: activity.color }}
                                >
                                    Start Now
                                </button>
                            </div>
                        ))}
                    </div>

                    <div className="wellness-tips">
                        <h3>💡 Wellness Tips</h3>
                        <div className="tips-grid">
                            <div className="tip">
                                <h4>Morning Routine</h4>
                                <p>Start your day with 5 minutes of deep breathing</p>
                            </div>
                            <div className="tip">
                                <h4>Digital Detox</h4>
                                <p>Take regular breaks from screens</p>
                            </div>
                            <div className="tip">
                                <h4>Stay Hydrated</h4>
                                <p>Drink water throughout the day</p>
                            </div>
                            <div className="tip">
                                <h4>Move Your Body</h4>
                                <p>Even short walks can boost mood</p>
                            </div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default WellnessCenter;